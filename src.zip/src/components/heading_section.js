import React from 'react';

const Header  = () => {
  return (
    <div>
        <h1>Welcome</h1>
        <p>Gumbo beet greens corn soko endive gumbo gourd. Parsley shallot courgette tatsoi pea sprouts fava bean collard greens.</p>
    </div>
  )
};

export default Header;
