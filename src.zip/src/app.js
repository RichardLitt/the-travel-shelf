import React, {Component} from 'react';
import Header from './components/heading_section';
import Navbar from './components/nav_bar';

class App extends Component {
  render() {
    return(
      <div>
          <Navbar />
          <header />
      </div>
    )
  }
};

export default App;
